﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace XamarinWebAPI.Models
{
    public class MemberModel
    {
        public virtual Guid ID { get; set; }
        public virtual UserModel User { get; set; }
        public virtual BandModel Band { get; set; }
        public virtual IList<Member_RoleModel> Member_Role { get; set; }
    }
}